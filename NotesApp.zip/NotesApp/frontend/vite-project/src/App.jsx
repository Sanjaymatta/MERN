
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import "./App.css";

const apiUrl = '/api/notes';
const App = () => {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState({ title: '', content: '' });
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchNotes();
  }, []);

  
  const fetchNotes = async () => {
    try {
      const response = await axios.get(apiUrl);
      setNotes(response.data);
      setError(null);
    } catch (err) {
      setError("Failed to fetch notes");
      console.error(err);
    }
  };
  
  const addNote = async (e) => {
    e.preventDefault();
    const requestBody = {
      title: newNote.title,
      content: newNote.content,
    };
  
    try {
      const response = await axios.post(apiUrl, requestBody);
      setNotes([...notes, response.data]);
      setNewNote({ title: "", content: "" });
      setError(null);
    } catch (err) {
      setError("Failed to add note");
      console.error(err);
    }
  };
  
  const deleteNote = async (id) => {
    try {
      await axios.delete(`${apiUrl}/${id}`);
      setNotes(notes.filter((note) => note._id !== id));
      setError(null);
    } catch (err) {
      setError("Failed to delete note");
      console.error(err);
    }
  };

  return (
    <div>
      <h1>Notes App</h1>
      <form onSubmit={addNote}>
        <input
          value={newNote.title}
          onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
          placeholder="Title"
        />
        <textarea
          value={newNote.content}
          onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
          placeholder="Content"
        ></textarea>
        <button type="submit">Add Note</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <ul>
        {notes.map((note) => (
          <li key={note._id}>
            <h3>{note.title}</h3>
            <p>{note.content}</p>
            <button onClick={() => deleteNote(note._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;

